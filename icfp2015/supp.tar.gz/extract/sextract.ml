type __ = Obj.t
let __ = let rec f _ = Obj.repr f in Obj.repr f

type 'a option =
| Some of 'a
| None

(** val snd : ('a1*'a2) -> 'a2 **)

let snd = function
| x,y -> y

type 'a list =
| Nil
| Cons of 'a * 'a list

type 'a sig0 =
  'a
  (* singleton inductive, whose constructor was exist *)

type ('sT, 'a) cS_Result = ('a*'sT)

(** val snoc : int -> int list -> 'a1 -> ('a1, int list) cS_Result **)

let rec snoc x l st =
  match l with
  | Nil -> (Cons (x, Nil)),st
  | Cons (y, sl) ->
    let c = snoc x sl st in let av,stA = c in (Cons (y, av)),stA

type sT = int list

(** val store_snoc : int -> sT -> (sT, unit) cS_Result **)

let store_snoc x st =
  let c = st,st in
  let av,stA = c in let c0 = snoc x av stA in let av0,stA0 = c0 in (),av0

type addr = int

(** val nULLptr : addr **)

let nULLptr =
  0

(** val addr_inc : addr -> addr **)

let addr_inc a =
  succ a

(** val addr_eq_dec : addr -> addr -> bool **)

let rec addr_eq_dec n y0 =
  (fun fO fS n -> if n=0 then fO () else fS (n-1))
    (fun _ ->
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ ->
      false)
      (fun n0 ->
      true)
      y0)
    (fun n0 ->
    (fun fO fS n -> if n=0 then fO () else fS (n-1))
      (fun _ ->
      true)
      (fun n1 ->
      addr_eq_dec n0 n1)
      y0)
    n

type 'c map = addr -> 'c option

(** val map_ext : 'a1 map -> addr -> 'a1 -> 'a1 map **)

let map_ext m a v a' =
  match addr_eq_dec a a' with
  | false -> Some v
  | true -> m a'

type 'c memory = addr*'c map

(** val mem_map : 'a1 memory -> 'a1 map **)

let mem_map mem =
  snd mem

(** val malloc : 'a1 -> 'a1 memory -> ('a1 memory, addr) cS_Result **)

let malloc init = function
| next,map0 -> next,((addr_inc next),(map_ext map0 next init))

type 'a sLL =
| NODE of 'a * addr

(** val memory_list_of_len :
    int -> int sLL memory -> (int sLL memory, addr) cS_Result **)

let rec memory_list_of_len n st =
  (fun fO fS n -> if n=0 then fO () else fS (n-1))
    (fun _ ->
    nULLptr,st)
    (fun m ->
    let c = memory_list_of_len m st in
    let av,stA = c in malloc (NODE (m, av)) stA)
    n

type 'a memory_reverse_loop_unfold_P = ('a sLL memory*addr) -> __

(** val memory_reverse_loop_unfold :
    ('a1 sLL memory*addr) -> 'a1 memory_reverse_loop_unfold_P **)

let rec memory_reverse_loop_unfold x =
  let iH = fun y -> memory_reverse_loop_unfold y in
  (fun mem'_a_before ->
  let mem0,a_after = x in
  let mem,a_before = mem'_a_before in
  Obj.magic (fun _ _ ->
    let v_after = mem_map mem0 a_after in
    (match v_after with
     | Some v_after0 ->
       let NODE (v_after1, a'_after) = v_after0 in
       let c = fun _ -> malloc (NODE (v_after1, a_before)) mem in
       let a'_before,mem' = c __ in
       let y = iH (mem',a'_after) (mem',a'_before) in
       let iHa,iHmem = Obj.magic y __ __ in iHa,iHmem
     | None -> a_before,mem0)))

(** val memory_reverse_loop :
    addr -> addr -> 'a1 sLL memory -> ('a1 sLL memory, addr) cS_Result **)

let memory_reverse_loop a_before a_after mem =
  Obj.magic memory_reverse_loop_unfold (mem,a_after) (mem,a_before) __ __

(** val memory_reverse :
    addr -> 'a1 sLL memory -> ('a1 sLL memory, addr) cS_Result **)

let memory_reverse a mem =
  memory_reverse_loop nULLptr a mem

